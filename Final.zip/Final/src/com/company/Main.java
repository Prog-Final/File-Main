package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int logPass;
        int logId;
        int selection;
        int partyID;
        int partyPass;
        int logOut;
        Scanner keyboard = new Scanner(System.in);
            System.out.println("Hello, and welcome to Party Inc.!\n Please remember your password we are about to give you.");
            System.out.println("Password: 269769 ");
            logPass = 269769;
            
            System.out.println("Please select an option from the listed below:\\n   1. Create new account\\n   2. Change account\\n   3. Delete account\\n   4. Exit");
            selection = keyboard.nextInt();
            if (selection == 1) {
                System.out.println("Please create your Party ID:");
                partyID = keyboard.nextInt();
                System.out.println("Please create your Party password:");
                partyPass = keyboard.nextInt();

            }
            if (selection == 2) {
                System.out.println("Are you sure you want to log out of the program?\n   1. Yes\n   2. No\n   3. Back");
                logOut = keyboard.nextInt();
                if (logOut == 1) {
                }
                if (logOut == 2) {
                    System.out.println("Returning to main menu.");
                }
                if (logOut == 3) {
                }
            if (selection == 3);
            }
        }
    }
