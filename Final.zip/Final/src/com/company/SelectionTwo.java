package com.company;

public class SelectionTwo {
    int logOut;
     System.out.println("Are you sure you want to log out of the program?\n   1. Yes\n   2. No\n   3. Back");
     logOut = keyboard.nextInt();
                if (logOut == 1) {
        cont = false;
    }
                if (logOut == 2) {
        System.out.println("Returning to main menu.");
        cont = false;
    }
                if (logOut == 3) {
        cont = false;
    }
}
